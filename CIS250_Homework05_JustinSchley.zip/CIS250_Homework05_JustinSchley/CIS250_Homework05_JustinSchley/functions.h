#pragma once
using namespace std;

int multiply(int first, int second);
int sum(int num);
int triangle(int num);
int power(int base, int exponent);
int countX(string xString);
int countX(string xString, int i, int count);